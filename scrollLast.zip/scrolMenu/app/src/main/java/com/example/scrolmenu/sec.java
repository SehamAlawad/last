package com.example.scrolmenu;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class sec extends AppCompatActivity {


    private String coffeeType;
    private String sweetType;
    private Button mkOrder;
    int i;
    private int numCofe1 = 1;
    private int numCofe2 = 1;
    private int numCofe3 = 1;
    private int numCofe4 = 1;
    private int numCofe5 = 1;
    private int numCofe6 = 1;
    private int numCofe7 = 1;
    private int numCofe8 = 1;
    private int numCofe9 = 1;
    private int numCofe10 = 1;
    private int numCofe11 = 1;
    private int numCofe12 = 1;
    private int numCofe13 = 1;
    private int numCofe14 = 1;

    TextView tx1;
    TextView tx2;
    TextView tx3;
    TextView tx4;
    TextView tx5;
    TextView tx6;
    TextView tx7;
    TextView tx8;
    TextView tx9;
    TextView tx10;
    TextView tx11;
    TextView tx12;
    TextView tx13;
    TextView tx14;


    TextView txtv1;
    TextView txtv2;
    TextView txtv3;
    TextView txtv4;
    TextView txtv5;
    TextView txtv6;
    TextView txtv7;
    TextView txtv8;
    TextView txtv9;
    TextView txtv10;
    TextView txtv11;
    TextView txtv12;
    TextView txtv13;
    TextView txtv14;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec);

        mkOrder = (Button) findViewById(R.id.button2);

        tx1 = (TextView) findViewById(R.id.carMacciatoP);
        tx2 = (TextView) findViewById(R.id.amrcP);
        tx3 = (TextView) findViewById(R.id.mochaP);
        tx4 = (TextView) findViewById(R.id.latteP);
        tx5 = (TextView) findViewById(R.id.esprsoP);
        tx6 = (TextView) findViewById(R.id.CappuccinoP);
        tx7 = (TextView) findViewById(R.id.frenchP);
        tx8 = (TextView) findViewById(R.id.chocoMochaP);
        tx9 = (TextView) findViewById(R.id.spanishP);
        tx10 = (TextView) findViewById(R.id.icedCrmlMacchiatoP);
        tx11 = (TextView) findViewById(R.id.BrowniesP);
        tx12 = (TextView) findViewById(R.id.MacaroonsP);
        tx13 = (TextView) findViewById(R.id.CookiesP);
        tx14 = (TextView) findViewById(R.id.CupcakesP);

        txtv1 = (TextView) findViewById(R.id.counter1);
        txtv2 = (TextView) findViewById(R.id.counter2);
        txtv3 = (TextView) findViewById(R.id.counter3);
        txtv4 = (TextView) findViewById(R.id.counter4);
        txtv5 = (TextView) findViewById(R.id.counter5);
        txtv6 = (TextView) findViewById(R.id.counter6);
        txtv7 = (TextView) findViewById(R.id.counter7);
        txtv8 = (TextView) findViewById(R.id.counter8);
        txtv9 = (TextView) findViewById(R.id.counter9);
        txtv10 = (TextView) findViewById(R.id.counter10);
        txtv11 = (TextView) findViewById(R.id.counter11);
        txtv12 = (TextView) findViewById(R.id.counter12);
        txtv13 = (TextView) findViewById(R.id.counter13);
        txtv14 = (TextView) findViewById(R.id.counter14);


        mkOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(sec.this, basket.class);

                //add data to intent
                i.putExtra("coffee_Type", coffeeType);
                i.putExtra("sweetType", sweetType);
                startActivity(i);


                finish();

            }

        });
    }

    public void selectCoffee(View view) {

        switch (view.getId()) {
            case R.id.crmlMachiatoBtn:
                coffeeType = "hot crmlMachiato";
                break;
            case R.id.mochaBtn:
                coffeeType += "hot mocha";
                break;
            case R.id.latteBtn:
                coffeeType += "hot latte";
                break;
            case R.id.esprsoBtn:
                coffeeType += "hot espresso";
                break;
            case R.id.CappuccinoBtn:
                coffeeType += "hot Cappuccino";
                break;
            case R.id.amrcanoBtn:
                coffeeType += "hot amricano";
                break;
            case R.id.frenchBtn:
                coffeeType += "ICED FRENCH VANILLA";
                break;
            case R.id.chocoMochaBtn:
                coffeeType += "ICED CHOCOLATE MOCHA";
                break;
            case R.id.spanishBtn:
                coffeeType += "ICED SPANISH LATTE";
                break;
            case R.id.icedCrmlMacchiatoBtn:
                coffeeType += "ICED Caramel Macchiato";

        }
    }

    public void selectSweets(View v) {

        switch (v.getId()) {
            case R.id.browniBtn:
                sweetType = "BROWNIES";
                break;
            case R.id.MacaroonsBtn:
                sweetType += "MACAROONS";
                break;
            case R.id.CookiesBtn:
                sweetType += "COOKIES";
                break;
            case R.id.CupcakesBtn:
                sweetType += "CUPCAKES";

        }
    }

    public void increment(View v) {

        switch (v.getId()) {
            case R.id.incBtn1:
                numCofe1 += 1;
                i = numCofe1*10;
                tx1.setText("" +i +" SR");
                txtv1.setText("" + numCofe1);
                break;
            case R.id.incBtn2:
                numCofe2 += 1;
                i = numCofe2*8;
                tx2.setText("" +i +" SR");
                txtv2.setText("" + numCofe2);
                break;
            case R.id.incBtn3:
                numCofe3 += 1;
                i = numCofe3*12;
                tx3.setText("" +i +" SR");
                txtv3.setText("" + numCofe3);
                break;
            case R.id.incBtn4:
                numCofe4 += 1;
                i = numCofe4*10;
                tx4.setText("" +i +" SR");
                txtv4.setText("" + numCofe4);
                break;
            case R.id.incBtn5:
                numCofe5 += 1;
                i = numCofe5*7;
                tx5.setText("" +i +" SR");
                txtv5.setText("" + numCofe5);
                break;
            case R.id.incBtn6:
                numCofe6 += 1;
                i = numCofe6*12;
                tx6.setText("" +i +" SR");
                txtv6.setText("" + numCofe6);
                break;
            case R.id.incBtn7:
                numCofe7 += 1;
                i = numCofe7*12;
                tx7.setText("" +i +" SR");
                txtv7.setText("" + numCofe7);
                break;
            case R.id.incBtn8:
                numCofe8 += 1;
                i = numCofe8*10;
                tx8.setText("" +i +" SR");
                txtv8.setText("" + numCofe8);
                break;
            case R.id.incBtn9:
                numCofe9 += 1;
                i = numCofe9*10;
                tx9.setText("" +i +" SR");
                txtv9.setText("" + numCofe9);
                break;
            case R.id.incBtn10:
                numCofe10 += 1;
                i = numCofe10*14;
                tx10.setText("" +i +" SR");
                txtv10.setText("" + numCofe10);
                break;
            case R.id.incBtn11:
                numCofe11 += 1;
                i = numCofe11*5;
                tx11.setText("" +i +" SR");
                txtv11.setText("" + numCofe11);
                break;
            case R.id.incBtn12:
                numCofe12 += 1;
                i = numCofe12*6;
                tx12.setText("" +i +" SR");
                txtv12.setText("" + numCofe12);
                break;
            case R.id.incBtn13:
                numCofe13 += 1;
                i = numCofe13*4;
                tx13.setText("" +i +" SR");
                txtv13.setText("" + numCofe13);
                break;
            case R.id.incBtn14:
                numCofe14 += 1;
                i = numCofe14*4;
                tx14.setText("" +i +" SR");
                txtv14.setText("" + numCofe14);

        }
    }

    public void decrement(View v) {

        if(v.getId()==R.id.decBtn1){
         if (numCofe1 > 1) {
            numCofe1 -= 1;
             i = numCofe1*10;
             tx1.setText("" +i +" SR");
            txtv1.setText("" + numCofe1);

        }  else{
                txtv1.setText("" + numCofe1);
            }}

        if (v.getId()==R.id.decBtn2){
         if (numCofe2 > 1) {
            numCofe2 -= 1;
             i = numCofe2*8;
             tx2.setText("" +i +" SR");
            txtv2.setText("" + numCofe2);

        }  else{
            txtv2.setText("" + numCofe2);
        }}

        if (v.getId()==R.id.decBtn3){
            if (numCofe3 > 1) {
                numCofe3 -= 1;
                i = numCofe3*12;
                tx3.setText("" +i +" SR");
                txtv3.setText("" + numCofe3);

            }  else{
                txtv3.setText("" + numCofe3);
            }}

        if (v.getId()==R.id.decBtn4){
            if (numCofe4 > 1) {
                numCofe4 -= 1;
                i = numCofe4*10;
                tx4.setText("" +i +" SR");
                txtv4.setText("" + numCofe4);

            }  else{
                txtv4.setText("" + numCofe4);
            }}

        if (v.getId()==R.id.decBtn5){
            if (numCofe5 > 1) {
                numCofe5 -= 1;
                i = numCofe5*7;
                tx5.setText("" +i +" SR");
                txtv5.setText("" + numCofe5);

            }  else{
                txtv5.setText("" + numCofe5);
            }}

        if (v.getId()==R.id.decBtn6){
            if (numCofe6 > 1) {
                numCofe6 -= 1;
                i = numCofe6*12;
                tx6.setText("" +i +" SR");
                txtv6.setText("" + numCofe6);

            }  else{
                txtv6.setText("" + numCofe6);
            }}

        if (v.getId()==R.id.decBtn7){
            if (numCofe7 > 1) {
                numCofe7 -= 1;
                i = numCofe7*12;
                tx7.setText("" +i +" SR");
                txtv7.setText("" + numCofe7);

            }  else{
                txtv7.setText("" + numCofe7);
            }}

        if (v.getId()==R.id.decBtn8){
            if (numCofe8 > 1) {
                numCofe8 -= 1;
                i = numCofe8*10;
                tx8.setText("" +i +" SR");
                txtv8.setText("" + numCofe8);

            }  else{
                txtv8.setText("" + numCofe8);
            }}

        if (v.getId()==R.id.decBtn9){
            if (numCofe9 > 1) {
                numCofe9 -= 1;
                i = numCofe9*10;
                tx9.setText("" +i +" SR");
                txtv9.setText("" + numCofe9);

            }  else{
                txtv9.setText("" + numCofe9);
            }}

        if (v.getId()==R.id.decBtn10){
            if (numCofe10 > 1) {
                numCofe10 -= 1;
                i = numCofe10*14;
                tx10.setText("" +i +" SR");
                txtv10.setText("" + numCofe10);

            }  else{
                txtv10.setText("" + numCofe10);
            }}

        if (v.getId()==R.id.decBtn11){
            if (numCofe11 > 1) {
                numCofe11 -= 1;
                i = numCofe11*5;
                tx11.setText("" +i +" SR");
                txtv11.setText("" + numCofe11);

            }  else{
                txtv11.setText("" + numCofe11);
            }}
        if (v.getId()==R.id.decBtn12){
            if (numCofe12 > 1) {
                numCofe12 -= 1;
                i = numCofe12*6;
                tx12.setText("" +i +" SR");
                txtv12.setText("" + numCofe12);

            }  else{
                txtv12.setText("" + numCofe12);
            }}

        if (v.getId()==R.id.decBtn13){
            if (numCofe13 > 1) {
                numCofe13 -= 1;
                i = numCofe13*4;
                tx13.setText("" +i +" SR");
                txtv13.setText("" + numCofe13);

            }  else{
                txtv13.setText("" + numCofe13);
            }}

        if (v.getId()==R.id.decBtn14){
            if (numCofe14 > 1) {
                numCofe14 -= 1;
                i = numCofe14*4;
                tx14.setText("" +i +" SR");
                txtv14.setText("" + numCofe14);

            }  else{
                txtv14.setText("" + numCofe14);
            }}

        }
    }


